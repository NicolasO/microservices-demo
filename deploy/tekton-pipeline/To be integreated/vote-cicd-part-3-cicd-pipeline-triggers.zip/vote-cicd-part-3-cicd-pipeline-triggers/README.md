# Vote-CICD
CICD Pipelines for Vote-API and Vote-UI
